
const config = {
    type: Phaser.AUTO,
    width: window.innerWidth,
    height: window.innerHeight,
    physics: {
        default: 'arcade',
        arcade: { gravity: { y: 300 }, debug: false }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    },
    parent: 'gameContainer'
};

let player, cursors, backgroundIndex = 0;
let backgrounds = ['bg_day', 'bg_evening', 'bg_night'];

const game = new Phaser.Game(config);

function preload() {
    this.load.image('car', 'assets/car.png');
    this.load.image('bg_day', 'assets/bg_day.png');
    this.load.image('bg_evening', 'assets/bg_evening.png');
    this.load.image('bg_night', 'assets/bg_night.png');
}

function create() {
    this.bg = this.add.image(0, 0, 'bg_day').setOrigin(0).setDisplaySize(this.sys.game.config.width, this.sys.game.config.height);
    this.time.addEvent({
        delay: 5000,
        callback: () => {
            backgroundIndex = (backgroundIndex + 1) % backgrounds.length;
            this.bg.setTexture(backgrounds[backgroundIndex]);
        },
        loop: true
    });

    player = this.physics.add.image(100, 300, 'car').setScale(0.5);
    player.setCollideWorldBounds(true);

    cursors = this.input.keyboard.createCursorKeys();
}

function update() {
    if (cursors.left.isDown) {
        player.setVelocityX(-200);
    } else if (cursors.right.isDown) {
        player.setVelocityX(200);
    } else {
        player.setVelocityX(0);
    }
}
